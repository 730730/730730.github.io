--[[
a = alarm
s = string

TODO:
-Whole SD file explorer
-Fix 1 as second digit on the font being on the left instead of the right 
 (by either modifying the font or printing single numbers (hard af))
-Turn off screens FOR REAL (can't be done (yet))
-Commentate (more?)
-Tidy up hour/min/sec variables variations (if possible)
-Puzzle solving
--]]
white = Color.new(255, 255, 255)
black = Color.new(0, 0, 0)
green = Color.new(0, 212, 20)
red = Color.new(212, 0, 0) 
softRed = Color.new(158, 0, 0)
softBlue = Color.new(13, 0, 158)
softGreen = Color.new(0, 158, 0)
softOrange = Color.new(224, 146, 0)
softCyan = Color.new(0, 173, 176)
softPurple = Color.new(136, 0, 181)
softMagenta = Color.new(196, 0, 193)
clockColor = {white, softRed, softBlue, softGreen, softOrange, softCyan, softPurple, softMagenta}
colorIndex = 1
alarm = ""
aHour = 0
aMins = 0
number = 0
menuPosition = 1
saHour = ""
saMins = ""
canPlay = false
debugMode = false
blackened = false
explorerOpen = true
up = Screen.loadImage(System.currentDirectory() .. "/images/up.png")
down = Screen.loadImage(System.currentDirectory() .. "/images/down.png")
up2 = Screen.loadImage(System.currentDirectory() .. "/images/up2.png")
down2 = Screen.loadImage(System.currentDirectory() .. "/images/down2.png")
switch = Screen.loadImage(System.currentDirectory() .. "/images/switch.png")
switch2 = Screen.loadImage(System.currentDirectory() .. "/images/switch2.png")
--http://www.dafont.com/digital-7.font
digital7 = Font.load(System.currentDirectory() .. "/digital-7.ttf")
alarms = System.listDirectory(System.currentDirectory() .. "/alarms")
function openExplorer()	
	while explorerOpen do
		pad = Controls.read()
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(TOP_SCREEN)
		y = 5
		for i, file in pairs(alarms) do
			if i == menuPosition then
				color = green
			else
				color = white
			end
			Screen.debugPrint(5, y, file.name, color, TOP_SCREEN)
			y = y + 15
		end
		if Controls.check(pad, KEY_A) then
			alarm = Sound.openWav(System.currentDirectory() .. "/alarms/" .. alarms[menuPosition].name)
			explorerOpen = false
		elseif Controls.check(pad, KEY_DUP) and not Controls.check(oldpad, KEY_DUP) then
			menuPosition = menuPosition - 1
		elseif Controls.check(pad, KEY_DDOWN) and not Controls.check(oldpad, KEY_DDOWN) then
			menuPosition = menuPosition + 1
		end
		if menuPosition > #alarms then
			menuPosition = 1
		elseif menuPosition < 1 then
			menuPosition = #alarms
		end
		Screen.flip()
		oldpad = pad
	end
end
if #alarms > 1 then
	openExplorer()
elseif #alarms == 1 then
	alarm = Sound.openWav(System.currentDirectory() .. "/alarms/" .. alarms[1].name)
	explorerOpen = false
else
	while true do
		pad = Controls.read()
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(TOP_SCREEN)
		Screen.debugPrint(5, 5, "No alarms found! Press Start to exit.", white, TOP_SCREEN)
		if (Controls.check(pad, KEY_START)) then
			Font.unload(digital7)
			System.exit()
		end
		Screen.flip()
	end
end
Sound.init()
Sound.pause(alarm)
while true do
	hour, mins, secs = System.getTime()
	sHour = hour
	sMins = mins
	sSecs = secs
	guiX = 80
	guiY = 40
	arrowIndex = -1
	img = nil
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(TOP_SCREEN)
	Screen.clear(BOTTOM_SCREEN)
	pad = Controls.read()
	tx, ty = Controls.readTouch()
	--Misc. controls
	if (Controls.check(pad, KEY_START)) then
		Font.unload(digital7)
		Sound.pause(alarm)
		Sound.close(alarm)
		Sound.term()
		System.exit()
	end
	if not explorerOpen then
		if (Controls.check(pad, KEY_A)) then
			canPlay = true
		end
		if (Controls.check(pad, KEY_B)) then
			canPlay = false
			Sound.pause(alarm)
		end
		if (Controls.check(pad, KEY_Y)) and not (Controls.check(oldpad, KEY_Y)) then
			if not #alarms == 1 then
				explorerOpen = true
			end
		end
		if (Controls.check(pad, KEY_X)) and not (Controls.check(oldpad, KEY_X)) then
			if blackened then
				blackened = false
			else
				blackened = true
			end
		end
		if (Controls.check(pad, KEY_R)) and not (Controls.check(oldpad, KEY_R)) then
			if colorIndex == #clockColor then
				colorIndex = 1
			else
				colorIndex = colorIndex + 1
			end
		end
		if (Controls.check(pad, KEY_L)) and not (Controls.check(oldpad, KEY_L)) then
			if colorIndex == 1 then
				colorIndex = #clockColor
			else
				colorIndex = colorIndex - 1
			end
		end
		if (Controls.check(pad, KEY_TOUCH)) and not Controls.check(oldpad, KEY_TOUCH) then
			blackened = false
		end
		if not canPlay then
			--Alarm time controls
			if (Controls.check(pad, KEY_DUP)) and not (Controls.check(oldpad, KEY_DUP)) then
				if (aHour ~= 23) then
					aHour = aHour + 1
				else
					aHour = 0
				end
			end
			if (Controls.check(pad, KEY_DDOWN)) and not (Controls.check(oldpad, KEY_DDOWN)) then
				if (aHour ~= 0) then
					aHour = aHour - 1
				else
					aHour = 23
				end
			end
			if (Controls.check(pad, KEY_DRIGHT)) and not (Controls.check(oldpad, KEY_DRIGHT)) then
				if (aMins ~= 59) then
					aMins = aMins + 1
				else
					aMins = 0
				end
			end
			if (Controls.check(pad, KEY_DLEFT)) and not (Controls.check(oldpad, KEY_DLEFT)) then
				if (aMins ~= 0) then
					aMins = aMins - 1
				else
					aMins = 59
				end
			end
			--Up arrow for hours
			if (tx >= guiX) and (tx <= guiX + 39) and (ty >= guiY) and (ty <= guiY + 39) then
				if not Controls.check(oldpad, KEY_TOUCH) then
					if (aHour ~= 23) then
						aHour = aHour + 1
					else
						aHour = 0
					end
				end
				arrowIndex = 0
			end
			--Down arrow for hours
			if (tx >= guiX) and (tx <= guiX + 39) and (ty >= guiY + 40) and (ty <= guiY + 79) then
				if not Controls.check(oldpad, KEY_TOUCH) then
					if (aHour ~= 0) then
						aHour = aHour - 1
					else
						aHour = 23
					end
				end
				arrowIndex = 1
			end
			--Up arrow for minutes
			if (tx >= guiX + 80) and (tx <= guiX + 119) and (ty >= guiY) and (ty <= guiY + 39) then
				if not Controls.check(oldpad, KEY_TOUCH) then
					if (aMins ~= 59) then
						aMins = aMins + 1
					else
						aMins = 0
					end
				end
				arrowIndex = 2
			end
			--Down arrow for minutes
			if (tx >= guiX + 80) and (tx <= guiX + 119) and (ty >= guiY + 40) and (ty <= guiY + 79) then
				if not Controls.check(oldpad, KEY_TOUCH) then
					if (aMins ~= 0) then
						aMins = aMins - 1
					else
						aMins = 59
					end
				end
				arrowIndex = 3
			end
		end
		--Touch screen handling for the switch
		if (tx >= guiX+19) and (tx <= guiX+138) and (ty >= guiY+90) and (ty <= guiY+139) and not Controls.check(oldpad, KEY_TOUCH) then
			if canPlay == false then	
				canPlay = true
			else
				canPlay = false
				Sound.pause(alarm)
			end
		end
		--Stylize time displayed
		saHour = aHour
		saMins = aMins
		if (string.len(tostring(hour)) == 1) then
			sHour = "0" .. hour
		end
		if (string.len(tostring(mins)) == 1) then
			sMins = "0" .. mins
		end
		if (string.len(tostring(secs)) == 1) then
			sSecs = "0" .. secs
		end
		if (string.len(tostring(aHour)) == 1) then
			saHour = "0" .. aHour
		end
		if (string.len(tostring(aMins)) == 1) then
			saMins = "0" .. aMins
		end
		--Play alarm
		if (hour == aHour) and (mins == aMins) and not Sound.isPlaying(alarm) and canPlay then
			Sound.play(alarm, LOOP, 0x09)
		end
		--PRINT ALL THE THINGS
		if not blackened then
			Font.setPixelSizes(digital7, 72)
			--Print colon
			if (secs % 2 == 0) or (secs == 0) then
				Font.print(digital7, 190, 55, ":", clockColor[colorIndex], TOP_SCREEN)
			end
			--Big Clock Offset = 41
			--------------------------------------------------------------------------
			--Print time (and adjust font for numbers 10-19 so the font doesn't move
			--and so it looks like an actual digital clock)
			--------------------------------------------------------------------------
			--Here we can observe horrible arbitrary numbers belonging to no variables whatsoever in their natural habitat
			if (hour >= 10) and (hour <= 19) then
				Font.print(digital7, 106, 55, sHour, clockColor[colorIndex], TOP_SCREEN)
			else 
				Font.print(digital7, 65, 55, sHour, clockColor[colorIndex], TOP_SCREEN)
			end
			if (mins >= 10) and (mins <= 19) then
				Font.print(digital7, 251, 55, sMins, clockColor[colorIndex], TOP_SCREEN)
			else 
				Font.print(digital7, 210, 55, sMins, clockColor[colorIndex], TOP_SCREEN)
			end
			--Some useful debugging data
			if debugMode then
				if #alarms > 1 then thing = ">" else thing = "<" end
				Screen.debugPrint(5, 5, sHour .. ":" .. sMins .. ":" .. sSecs, white, TOP_SCREEN)
				Screen.debugPrint(5, 20, aHour .. ":" .. aMins, white, TOP_SCREEN)
				Screen.debugPrint(5, 35, "isPlaying: " .. tostring(Sound.isPlaying(alarm)), white, TOP_SCREEN)
				Screen.debugPrint(5, 50, tx .. "," .. ty, white, TOP_SCREEN)
				Screen.debugPrint(5, 65, "canPlay: " .. tostring(canPlay), white, TOP_SCREEN)
				Screen.debugPrint(5, 80, tostring(explorerOpen), white, TOP_SCREEN)
				Screen.debugPrint(5, 95, tostring(#alarms), white, TOP_SCREEN)
				Screen.debugPrint(5, 110, thing, white, TOP_SCREEN)
			end
			--Indicates that the alarm is turned on
			if canPlay then	
				Screen.debugPrint(365, 5, "ON", green, TOP_SCREEN)
			end
			--Draw bottom screen stuff
			Screen.drawImage(guiX, guiY, up, BOTTOM_SCREEN)
			Screen.drawImage(guiX, guiY+40, down, BOTTOM_SCREEN)
			Screen.drawImage(guiX+80, guiY, up, BOTTOM_SCREEN)
			Screen.drawImage(guiX+80, guiY+40, down, BOTTOM_SCREEN)
			if arrowIndex == 0 then img = up2 else img = up end Screen.drawImage(guiX, guiY, img, BOTTOM_SCREEN)
			if arrowIndex == 1 then img = down2 else img = down end Screen.drawImage(guiX, guiY+40, img, BOTTOM_SCREEN)
			if arrowIndex == 2 then img = up2 else img = up end Screen.drawImage(guiX+80, guiY, img, BOTTOM_SCREEN)
			if arrowIndex == 3 then img = down2 else img = down end Screen.drawImage(guiX+80, guiY+40, img, BOTTOM_SCREEN)
			Screen.fillRect(guiX+40, guiX+79, guiY+1, guiY+78, white, BOTTOM_SCREEN)
			Screen.fillRect(guiX+120, guiX+159, guiY+1, guiY+78, white, BOTTOM_SCREEN)
			--Print alarm time (and adjust font for numbers 10-19 so the font doesn't move
			--and so it looks like an actual digital clock)
			Font.setPixelSizes(digital7, 24)
			if (aHour >= 10) and (aHour <= 19) then
				Font.print(digital7, guiX+54, guiY+23, saHour, black, BOTTOM_SCREEN)
			else 
				Font.print(digital7, guiX+41, guiY+23, saHour, black, BOTTOM_SCREEN)
			end
			if (aMins >= 10) and (aMins <= 19) then
				Font.print(digital7, guiX+134, guiY+23, saMins, black, BOTTOM_SCREEN)
			else 
				Font.print(digital7, guiX+121, guiY+23, saMins, black, BOTTOM_SCREEN)
			end
			--Draw switch
			if canPlay == true then img = switch2 else img = switch end Screen.drawImage(guiX+19, guiY+90, img, BOTTOM_SCREEN)
		end
	end
	if explorerOpen then
		Sound.pause(alarm)
		Sound.close(alarm)
		openExplorer()
	end
	Screen.flip()
	--[[if (Controls.check(pad, KEY_Y)) and not (Controls.check(oldpad, KEY_Y)) then
		System.takeScreenshot(System.currentDirectory .."/screenshot" .. number .. ".jpg", false)
		number = number + 1
	end--]]
	oldpad = pad
	oldtx = tx
	oldty = ty
end