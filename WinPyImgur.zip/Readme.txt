.py and .cmd go in C:/Windows
Install .reg